#include "utility.cpp"
#define endl '\n'

using namespace std;

int main() {
    srand(time(NULL)); //Force rand() to produce pseudo-random numbers non-deterministically
    vector<vector<vector<char>>> ttt(4, vector<vector<char>> (4, vector<char> (4, '#')));
    int user_option = -1;
    bool user_x_player;
    opponent user_opponent_option;

    //Choose Opponent
    cout << "Welcome to 3D tic tac toe!" << endl;
    printOpponentMenu();
    while(user_option < 1 || user_option > 3) {
        cout << "Choose Opponent: " ;
        cin >> user_option;
        if(user_option < 1 || user_option > 3)
            cout << "Please make a valid choice!" << endl;
    }
    if(user_option == 1)
        user_opponent_option = preschool_child;
    else if(user_option == 2)
        user_opponent_option = diamantis;
    else if(user_option == 3)
        user_opponent_option = professor_lagoudakis;
    else 
        cout << "It should be impossible for the program to reach this code!" << endl;

    //Choose Difficulty & Play The Game
    int difficulty = 0;
    printOpponentInformation(user_opponent_option);
    switch(user_opponent_option) {
        case preschool_child:
            user_x_player = userTurnChoice();
            printTicTacToe(ttt);
            play_the_game_random(ttt, user_x_player);
            break;
        case diamantis:
            printDiamantisOptions();
            difficulty = choose_opponent_difficulty(1, 3);
            user_x_player = userTurnChoice();
            printTicTacToe(ttt);
            play_the_game_mcts(ttt, user_x_player, difficulty);
            break;
        case professor_lagoudakis:
            printProfessorLagoudakisOptions();
            difficulty = choose_opponent_difficulty(1, 5);
            user_x_player = userTurnChoice();
            printTicTacToe(ttt);
            play_the_game_minimax(ttt, user_x_player, difficulty);
            break;
        default:
            cout << "It should be impossible for the program to reach this code!" << endl;
    }

    if((playerWinFast(ttt, 'X') && user_x_player) || (playerWinFast(ttt, 'O') && !user_x_player))
        cout << "You Won!" << endl;
    else if(available_moves(ttt).size() == 0)
        cout << "The Game Ended in a Draw!" << endl;
    else
        cout << "Computer Won!" << endl;

    return 0;
}