Each of the 4 tests needs a few hours to run on an average modern PC.
If the user is to try and run these tests he is free to lower the "samples" variable and recompile the code.