#include "../utility.cpp"
#define endl '\n'

using namespace std;

void print_statistics(vector<int> &depths, vector<int> &x_win_counter, vector<int> &o_win_counter, int samples) {
    for(int i = 0; i < x_win_counter.size(); i++) {
        int depth = depths[i];
        int x_wins = x_win_counter[i];
        int o_wins = o_win_counter[i];
        double x_win_ratio = (double)x_wins/samples;
        double o_win_ratio = (double)o_wins/samples;
        printf("For depth = %d: \'X\' won %f%% of the games & \'O\' won %.2f%% of the games!\n", depth, 100*x_win_ratio, 100*o_win_ratio);
    }
}

void initialize_wins(vector<int> &win_counter) {
    for(int i = 0; i < win_counter.size(); i++)
        win_counter[i] = 0;
}

/*
int main() {
    srand(time(NULL));
    vector<vector<vector<char>>> ttt(4, vector<vector<char>> (4, vector<char> (4, '#')));
    int samples = 1;
    vector<int> depths_to_test = {1, 2, 3, 4, 5, 6, 7};
    vector<int> x_win_counter(depths_to_test.size());
    vector<int> o_win_counter(depths_to_test.size());
    tuple<int, int, int> move_to_make;
    clock_t start, stop;
    double duration;
    
    start = clock();
    //first evaluation function is 'X' and 'O'.
    for(int index = 0; index < depths_to_test.size(); index++) {
        MAX_DEPTH = depths_to_test[index];
        cout << "Executing tests for depth " << MAX_DEPTH << "/7" << endl;
        for(int i = 0; i < samples; i++) {
            initializeTicTacToe(ttt);
            //printTicTacToe(ttt);
            while(!game_over(ttt)) {
                tuple<int, int, int> theoritical_move = get_theoritical_move(ttt, available_moves(ttt).size());
                if(get<0>(theoritical_move) != -1 && get<1>(theoritical_move) != -1 && get<2>(theoritical_move) != -1)
                    move_to_make = theoritical_move;
                else {
                    minimax_ret x_player = minimax_ab_pruning(ttt, 0, INT_MIN, INT_MAX, true, evaluation);
                    if(x_player.score == INT_MIN)
                        x_player.move = available_moves(ttt)[0];
                    move_to_make = x_player.move;
                }
                ttt[get<0>(move_to_make)][get<1>(move_to_make)][get<2>(move_to_make)] = 'X';
                //cout << "=====================================" << endl;
                //printTicTacToe(ttt);
                theoritical_move = get_theoritical_move(ttt, available_moves(ttt).size());
                if(get<0>(theoritical_move) != -1 && get<1>(theoritical_move) != -1 && get<2>(theoritical_move) != -1)
                    move_to_make = theoritical_move;
                else {
                    minimax_ret o_player = minimax_ab_pruning(ttt, 0, INT_MIN, INT_MAX, false, evaluation);
                    if(o_player.score == INT_MAX)
                        o_player.move = available_moves(ttt)[0];
                    move_to_make = o_player.move;
                }
                ttt[get<0>(move_to_make)][get<1>(move_to_make)][get<2>(move_to_make)] = 'O';
                //cout << "=====================================" << endl;
                //printTicTacToe(ttt);
            }
            if(playerWinFast(ttt, 'X'))
                x_win_counter[index]++;
            else if(playerWinFast(ttt, 'O'))
                o_win_counter[index]++;
        }
    }
    cout << "When the first evaluation function is both \'X\' and \'O\'" << endl;
    print_statistics(depths_to_test, x_win_counter, o_win_counter, samples);
    stop = clock();
    duration = (double)(clock() - start)/CLOCKS_PER_SEC;
    printf("Run Time: %.2f minutes\n\n", duration/60);

    initialize_wins(x_win_counter);
    initialize_wins(o_win_counter);
    start = clock();
    //first evaluation function 'X' and second evaluation function is 'O'.
    for(int index = 0; index < depths_to_test.size(); index++) {
        MAX_DEPTH = depths_to_test[index];
        cout << "Executing tests for depth " << MAX_DEPTH << "/7" << endl;
        for(int i = 0; i < samples; i++) {
            initializeTicTacToe(ttt);
            //printTicTacToe(ttt);
            while(!game_over(ttt)) {
                tuple<int, int, int> theoritical_move = get_theoritical_move(ttt, available_moves(ttt).size());
                if(get<0>(theoritical_move) != -1 && get<1>(theoritical_move) != -1 && get<2>(theoritical_move) != -1)
                    move_to_make = theoritical_move;
                else {
                    minimax_ret x_player = minimax_ab_pruning(ttt, 0, INT_MIN, INT_MAX, true, evaluation);
                    if(x_player.score == INT_MIN)
                        x_player.move = available_moves(ttt)[0];
                    move_to_make = x_player.move;
                }
                ttt[get<0>(move_to_make)][get<1>(move_to_make)][get<2>(move_to_make)] = 'X';
                //cout << "=====================================" << endl;
                //printTicTacToe(ttt);
                theoritical_move = get_theoritical_move(ttt, available_moves(ttt).size());
                if(get<0>(theoritical_move) != -1 && get<1>(theoritical_move) != -1 && get<2>(theoritical_move) != -1)
                    move_to_make = theoritical_move;
                else {
                    minimax_ret o_player = minimax_ab_pruning(ttt, 0, INT_MIN, INT_MAX, false, evaluation2);
                    if(o_player.score == INT_MAX)
                        o_player.move = available_moves(ttt)[0];
                    move_to_make = o_player.move;
                }
                ttt[get<0>(move_to_make)][get<1>(move_to_make)][get<2>(move_to_make)] = 'O';
                //cout << "=====================================" << endl;
                //printTicTacToe(ttt);
            }
            if(playerWinFast(ttt, 'X'))
                x_win_counter[index]++;
            else if(playerWinFast(ttt, 'O'))
                o_win_counter[index]++;
        }
    }
    cout << "When the first evaluation function is \'X\' and the second evaluation function is \'O\'" << endl;
    print_statistics(depths_to_test, x_win_counter, o_win_counter, samples);
    stop = clock();
    duration = (double)(clock() - start)/CLOCKS_PER_SEC;
    printf("Run Time: %.2f minutes\n\n", duration/60);

    initialize_wins(x_win_counter);
    initialize_wins(o_win_counter);
    start = clock();
    //first evaluation function is 'O' and second evaluation function is 'X'.
    for(int index = 0; index < depths_to_test.size(); index++) {
        MAX_DEPTH = depths_to_test[index];
        cout << "Executing tests for depth " << MAX_DEPTH << "/7" << endl;
        for(int i = 0; i < samples; i++) {
            initializeTicTacToe(ttt);
            //printTicTacToe(ttt);
            while(!game_over(ttt)) {
                tuple<int, int, int> theoritical_move = get_theoritical_move(ttt, available_moves(ttt).size());
                if(get<0>(theoritical_move) != -1 && get<1>(theoritical_move) != -1 && get<2>(theoritical_move) != -1)
                    move_to_make = theoritical_move;
                else {
                    minimax_ret x_player = minimax_ab_pruning(ttt, 0, INT_MIN, INT_MAX, true, evaluation2);
                    if(x_player.score == INT_MIN)
                        x_player.move = available_moves(ttt)[0];
                    move_to_make = x_player.move;
                }
                ttt[get<0>(move_to_make)][get<1>(move_to_make)][get<2>(move_to_make)] = 'X';
                //cout << "=====================================" << endl;
                //printTicTacToe(ttt);
                theoritical_move = get_theoritical_move(ttt, available_moves(ttt).size());
                if(get<0>(theoritical_move) != -1 && get<1>(theoritical_move) != -1 && get<2>(theoritical_move) != -1)
                    move_to_make = theoritical_move;
                else {
                    minimax_ret o_player = minimax_ab_pruning(ttt, 0, INT_MIN, INT_MAX, false, evaluation);
                    if(o_player.score == INT_MAX)
                        o_player.move = available_moves(ttt)[0];
                    move_to_make = o_player.move;
                }
                ttt[get<0>(move_to_make)][get<1>(move_to_make)][get<2>(move_to_make)] = 'O';
                //cout << "=====================================" << endl;
                //printTicTacToe(ttt);
            }
            if(playerWinFast(ttt, 'X'))
                x_win_counter[index]++;
            else if(playerWinFast(ttt, 'O'))
                o_win_counter[index]++;
        }
    }
    cout << "When the first evaluation function is \'O\' and the second evaluation function is \'X\'" << endl;
    print_statistics(depths_to_test, x_win_counter, o_win_counter, samples);
    stop = clock();
    duration = (double)(clock() - start)/CLOCKS_PER_SEC;
    printf("Run Time: %.2f minutes\n\n", duration/60);
    
    initialize_wins(x_win_counter);
    initialize_wins(o_win_counter);
    start = clock();
    //second evaluation function is 'X' and 'O'.
    for(int index = 0; index < depths_to_test.size(); index++) {
        MAX_DEPTH = depths_to_test[index];
        cout << "Executing tests for depth " << MAX_DEPTH << "/7" << endl;
        for(int i = 0; i < samples; i++) {
            initializeTicTacToe(ttt);
            //printTicTacToe(ttt);
            while(!game_over(ttt)) {
                tuple<int, int, int> theoritical_move = get_theoritical_move(ttt, available_moves(ttt).size());
                if(get<0>(theoritical_move) != -1 && get<1>(theoritical_move) != -1 && get<2>(theoritical_move) != -1)
                    move_to_make = theoritical_move;
                else {
                    minimax_ret x_player = minimax_ab_pruning(ttt, 0, INT_MIN, INT_MAX, true, evaluation2);
                    if(x_player.score == INT_MIN)
                        x_player.move = available_moves(ttt)[0];
                    move_to_make = x_player.move;
                }
                ttt[get<0>(move_to_make)][get<1>(move_to_make)][get<2>(move_to_make)] = 'X';
                //cout << "=====================================" << endl;
                //printTicTacToe(ttt);
                theoritical_move = get_theoritical_move(ttt, available_moves(ttt).size());
                if(get<0>(theoritical_move) != -1 && get<1>(theoritical_move) != -1 && get<2>(theoritical_move) != -1)
                    move_to_make = theoritical_move;
                else {
                    minimax_ret o_player = minimax_ab_pruning(ttt, 0, INT_MIN, INT_MAX, false, evaluation2);
                    if(o_player.score == INT_MAX)
                        o_player.move = available_moves(ttt)[0];
                    move_to_make = o_player.move;
                }
                ttt[get<0>(move_to_make)][get<1>(move_to_make)][get<2>(move_to_make)] = 'O';
                //cout << "=====================================" << endl;
                //printTicTacToe(ttt);
            }
            if(playerWinFast(ttt, 'X'))
                x_win_counter[index]++;
            else if(playerWinFast(ttt, 'O'))
                o_win_counter[index]++;
        }
    }
    cout << "When the second evaluation function is both \'X\' and \'O\'" << endl;
    print_statistics(depths_to_test, x_win_counter, o_win_counter, samples);
    stop = clock();
    duration = (double)(clock() - start)/CLOCKS_PER_SEC;
    printf("Run Time: %.2f minutes\n\n", duration/60);

    return 0;
}
*/